#!/bin/bash

find . -name '*.class' | xargs rm
find . -name '*~' | xargs rm

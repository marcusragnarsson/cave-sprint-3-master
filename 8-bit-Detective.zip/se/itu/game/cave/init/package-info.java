/**
 * Classes for initializing a game.
 */

package se.itu.game.cave.init;


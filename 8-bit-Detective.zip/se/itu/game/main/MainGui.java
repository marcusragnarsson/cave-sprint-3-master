package se.itu.game.main;

import se.itu.game.gui.MainFrame;
import se.itu.game.cave.Music;

public class MainGui {

  public static void main(String[] args) {
Music music = new Music("music.wav");
music.play();
    MainFrame mainFrame = new MainFrame();
    mainFrame.run();
  }

}
